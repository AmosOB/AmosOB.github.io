<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
// require __DIR__ . '/vendor/autoload.php';

$errors = [];
$errorMessage = '';
$messageSuccess = '';

$secret = '6LdZnpkgAAAAAGmgNsSgo0h79aHM6fo2g70Lbaap';


if (!empty($_POST)) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    if (empty($name)) {
        $errors[] = 'Name is empty';
    }

    if (empty($email)) {
        $errors[] = 'Email is empty';
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Email is invalid';
    }

    if (empty($message)) {
        $errors[] = 'Message is empty';
    }

    $recaptchaResponse = $_POST['g-recaptcha-response'];
    $secret = '6LfpY8UgAAAAABXXAvO8IpUVIAqi05VIEmIJEv9G';
    $recaptchaUrl = "https://www.google.com/recaptcha/api/siteverify?secret={$secret}&response={$recaptchaResponse}";
    $verify = json_decode(file_get_contents($recaptchaUrl));
     if (!$verify->success) {
      $errors[] = 'Recaptcha failed';
    }

    if (!empty($errors)) {
        $allErrors = join('<br/>', $errors);
        $errorMessage = "<p style='color: red;'>{$allErrors}</p>";
    } else {
            require 'vendor/autoload.php';

            $mail = new PHPMailer;

            //$mail->SMTPDebug = 4;                               // Enable verbose debug output

            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = 'smtp.mailtrap.io';  // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'd47db2ef5bc4a5';                 // SMTP username
            $mail->Password = '3a7d6ef83cd9c6';                           // SMTP password
            $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 2525;                                    // TCP port to connect to

            $mail->setFrom($email, 'Mailtrap Website');
            $mail->addAddress('okumuamos88@gmail.com', 'Amos Babu');     // Add a recipient
            $mail->addReplyTo($email);

            // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
            $mail->isHTML(true);                                  // Set email format to HTML

            $mail->Subject = 'New message from iGrowers InfoHub';
            $bodyParagraphs = ["Name: {$name}", "Email: {$email}", "Message:", nl2br($message)];
            $body = join('<br />', $bodyParagraphs); 
            $mail->Body    = $body;
            $mail->AltBody = $_POST['message'];

            if(!$mail->send()) {
                echo 'Message could not be sent.';
                echo 'Mailer Error: ' . $mail->ErrorInfo;
            } else {

               $_SESSION['status'] = "Message Sent Successfully!";
               header('location: contact.php');
                
            }
    }
}


?>